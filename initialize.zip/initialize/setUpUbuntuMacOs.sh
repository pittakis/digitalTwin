#!/usr/bin/env bash
set -euo pipefail

# Resolve paths relative to this script
DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)"
PROJECT_DIR="$(cd "$DIR/.." && pwd)"
BACKEND_DIR="$PROJECT_DIR/backend"
FRONTEND_DIR="$PROJECT_DIR/frontend"
PUBLIC_DIR="$FRONTEND_DIR/public"

# Verify structure
[ -d "$BACKEND_DIR" ] || { echo "Missing: $BACKEND_DIR"; exit 1; }
[ -d "$FRONTEND_DIR" ] || { echo "Missing: $FRONTEND_DIR"; exit 1; }
mkdir -p "$PUBLIC_DIR"

echo "==> Setting up environment files..."
if [ -f "$DIR/.env_backend" ]; then
  cp -f "$DIR/.env_backend" "$BACKEND_DIR/.env"
  echo "  + .env_backend -> backend/.env"
else
  echo "  (.env_backend not found in initialize/)"
fi

if [ -f "$DIR/.env_frontend" ]; then
  cp -f "$DIR/.env_frontend" "$FRONTEND_DIR/.env"
  echo "  + .env_frontend -> frontend/.env"
else
  echo "  (.env_frontend not found in initialize/)"
fi

echo "==> Copying assets to frontend/public..."
# Skip envs, setup scripts, and readmes
SCRIPT_BASENAME="$(basename -- "${BASH_SOURCE[0]}")"
shopt -s dotglob nullglob
for item in "$DIR"/*; do
  name="$(basename "$item")"
  case "$name" in
    .env_backend|.env_frontend|$SCRIPT_BASENAME|setUpWindows.ps1|README.md|README_initialize.md) continue ;;
  esac
  if [ -d "$item" ]; then
    rsync -a "$item"/ "$PUBLIC_DIR/$name"/
    echo "  + dir: $name -> frontend/public/$name/"
  else
    cp -f "$item" "$PUBLIC_DIR/$name"
    echo "  + file: $name -> frontend/public/"
  fi
done

echo
echo "All done"
