#Requires -Version 5.0
$ErrorActionPreference = "Stop"

# Resolve paths
$InitDir    = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProjectDir = Resolve-Path (Join-Path $InitDir "..")
$BackendDir = Join-Path $ProjectDir "backend"
$FrontendDir= Join-Path $ProjectDir "frontend"
$PublicDir  = Join-Path $FrontendDir "public"

# Verify structure
foreach ($p in @($BackendDir, $FrontendDir)) {
  if (-not (Test-Path -LiteralPath $p)) {
    throw "Expected path not found: $p (is 'initialize' directly under the project root?)"
  }
}
if (-not (Test-Path -LiteralPath $PublicDir)) { New-Item -ItemType Directory -Path $PublicDir | Out-Null }

# Copy env files with rename
$EnvBackendSrc  = Join-Path $InitDir ".env_backend"
$EnvFrontendSrc = Join-Path $InitDir ".env_frontend"

Write-Host "==> Setting up environment files..."
if (Test-Path -LiteralPath $EnvBackendSrc) {
  Copy-Item -LiteralPath $EnvBackendSrc -Destination (Join-Path $BackendDir ".env") -Force
  Write-Host "  + .env_backend -> backend/.env"
} else { Write-Warning "  (.env_backend not found in initialize/)" }

if (Test-Path -LiteralPath $EnvFrontendSrc) {
  Copy-Item -LiteralPath $EnvFrontendSrc -Destination (Join-Path $FrontendDir ".env") -Force
  Write-Host "  + .env_frontend -> frontend/.env"
} else { Write-Warning "  (.env_frontend not found in initialize/)" }

# Copy all other files/dirs into frontend/public (excluding certain files)
Write-Host "==> Copying assets to frontend/public..."
$scriptName = [System.IO.Path]::GetFileName($MyInvocation.MyCommand.Path)
$exclude = @(
  ".env_backend", ".env_frontend", 
  $scriptName, "setUpUbuntuMacOs.sh",
  "setUpWindows.ps1"
  "README.md", "README_initialize.md"
)

Get-ChildItem -LiteralPath $InitDir -Force | ForEach-Object {
  if ($exclude -contains $_.Name) { return }
  $dest = Join-Path $PublicDir $_.Name
  if ($_.PSIsContainer) {
    Copy-Item -Recurse -Force -LiteralPath $_.FullName -Destination $dest
    Write-Host "  + dir: $($_.Name) -> frontend/public/$($_.Name)/"
  } else {
    Copy-Item -Force -LiteralPath $_.FullName -Destination $dest
    Write-Host "  + file: $($_.Name) -> frontend/public/"
  }
}

Write-Host "`nAll done"
